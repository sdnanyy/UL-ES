import { Stringifier } from './postcss.js'

interface Stringify extends Stringifier {
  default: Stringify
}

declare const stringify: Stringify

export = stringify
