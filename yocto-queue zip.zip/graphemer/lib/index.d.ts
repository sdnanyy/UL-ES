import Graphemer from './Graphemer';
export default Graphemer;
//# sourceMappingURL=index.d.ts.map